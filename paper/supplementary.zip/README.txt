SUPPLEMENTARY MATERIALS
======================
Agent Organizational Management (AOM) - V5.2
Mechanism Decomposition in Multi-Agent Workflows
June 2026

CONTENTS
--------

1. experiment_logs/
   - deepseek_results.json        : DeepSeek experiment summary (all 4 conditions)
   - mimo_results.json            : MiMo experiment summary (all 4 conditions)
   - condition_abcd_logs/         : Per-condition detailed logs
     - deepseek/condition_A-D/    : token_usage.json + context_growth.txt
     - mimo/condition_A-D/        : token_usage.json + context_growth.txt
   - REPORT.md                    : Full experiment analysis report

2. outputs/
   - deepseek/condition_A-D/      : HTML outputs from DeepSeek (perler bead app)
   - mimo/condition_A-D/          : HTML outputs from MiMo (perler bead app)
   - snake_game/                  : Snake game outputs from V4 experiment

3. algorithm/
   - OIMAC_full_pseudocode.pdf    : Complete OIMAC algorithm with 7-phase pseudocode

4. system/
   - architecture_details.pdf     : Nine-module architecture specification

5. prompts/
   - coordinator.txt              : Coordinator role prompt
   - product_manager.txt          : Product manager role prompt
   - architect.txt                : Architect role prompt
   - frontend_dev.txt             : Frontend developer role prompt
   - image_processing_dev.txt     : Image processing developer role prompt
   - tester.txt                   : Tester role prompt

EXPERIMENT CONDITIONS
---------------------
A: Single agent, single call (baseline)
B: Single agent, 7 rounds iterative (CAE condition)
C: OIMAC + Context Controller (6 roles, bounded context)
D: OIMAC - Context Controller (6 roles, full context - ablation)

KEY RESULTS
-----------
                        DeepSeek    MiMo
Condition A:            6,587       8,251
Condition B:            88,494      102,105
Condition C:            43,321      49,285
Condition D:            58,718      63,050

C/B ratio (OIMAC):     2.04x       2.07x
D/C ratio (CC):        1.36x       1.28x

CDE contribution:       ~75% (primary driver)
CC contribution:        ~25% (secondary mechanism)

CONTACT
-------
Haoran Jiang
South China University of Technology
JiangLin1297@163.com
